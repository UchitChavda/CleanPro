import { View, Text, StyleSheet, Image } from 'react-native'
import React from 'react'
import { ScrollView } from 'react-native-gesture-handler'

const SenGraph = ({ navigation, route }) => {

const {sensorName, sensorValue} = route.params;

    return (
        <ScrollView>
        <View style={sgstyles.sgBody}>
            <View style={sgstyles.sgTitleView}>
                <Text style={sgstyles.sgSenTitle}>Sensor Name: </Text>
                <Text style={sgstyles.sgSenNameField}>{sensorName}</Text>
            </View>
            <View style={sgstyles.sgTitleView}>
                <Text style={sgstyles.sgSenTitle}>Sensor Value: </Text>
                <Text style={sgstyles.sgSenValueField}>{sensorValue}</Text>
            </View>
            <View style={sgstyles.sgGraphView}>
                <Text style={sgstyles.sgGraphTitle}>Sensor Data Graph : </Text>
                <ScrollView style={sgstyles.sgGraphCard}>
                    <Image
                        source={require('../Images/image.png')}
                        style={sgstyles.sgGraph}
                        />
                </ScrollView>
            </View>
        </View>
        </ScrollView>
    )
}

const sgstyles = StyleSheet.create({
    sgBody: {
        backgroundColor: 'white',
        minHeight: 700,
    },
    sgGraphView: {
        marginTop: 50
    },
    sgGraphCard: {
        backgroundColor: 'white',
        minHeight: 200,
        marginTop: 10,
        margin: 20,
        borderRadius: 20,
        elevation: 20,
    },
    sgTitleView: {
        flexDirection: 'row',
        marginLeft: 20
    },
    sgSenTitle: {
        fontSize: 25,
        fontWeight: '500',
        // flex: 1,
        color: "black",
    },
    sgSenNameField: {
        fontSize: 25,
        fontWeight: '500',
        // flex: 1,
        color: "black",
        width: 200,
        backgroundColor: 'red'
    },
    sgSenValueField: {
        fontSize: 25,
        fontWeight: '500',
        // flex: 1,
        color: "black",
        // width: 210,
        // backgroundColor: 'red'
    },
    sgGraph: {
        maxWidth: 500,
        margin: 30,
        padding: 0,
        width: 350,
        justifyContent: 'center',
        alignSelf: 'center',
        // marginLeft: 200
    },
    sgGraphTitle: {
        fontSize: 30,
        fontWeight: '500',
        color: "black",
        marginLeft: 20
    }
})

export default SenGraph